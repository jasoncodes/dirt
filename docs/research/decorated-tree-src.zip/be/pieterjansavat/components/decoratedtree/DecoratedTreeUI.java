/**
 *    Copyright 2006 Pieter-Jan Savat
 *    
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *    
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package be.pieterjansavat.components.decoratedtree;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.RenderingHints;

import javax.swing.ImageIcon;
import javax.swing.plaf.basic.BasicTreeUI;
import javax.swing.tree.TreePath;

public class DecoratedTreeUI extends BasicTreeUI {

	public static ImageIcon collapsedImage = new ImageIcon(DecoratedTreeUI.class.getResource("right-arrow.png"));
	public static ImageIcon expandedImage = new ImageIcon(DecoratedTreeUI.class.getResource("down-arrow.png"));
	public static ImageIcon noChildrenImage = new ImageIcon(DecoratedTreeUI.class.getResource("no-arrow.png"));
	
	public static Color parentTopBorder1Color = new Color(138,171,211);
	public static Color parentTopBorder2Color = new Color(134,176,219);
	public static Color parentTopColor = new Color(168,204,235);
	public static Color parentBottomColor = new Color(99,144,197);
	public static Color parentBottomBorder1Color = new Color(167,193,225);

	public static Color childColorOdd = new Color(238,243,250);
	public static Color childColorEven = new Color(252,253,254);

	public static Color selectectionMask = new Color(35, 80, 148, 90);

	public static Color parentFontColor = Color.WHITE;
	public static Color childFontColor = Color.BLACK;
	
	public static Font 	rowFont = new Font("Verdana", Font.PLAIN, 12); 

	public static boolean 		SHADOW = false;
	public static int 			SLIDE_STEPS = 4;
	public static boolean 		SLIDE = true; 
	public static boolean 		SLIDE_TEXT_ONLY = true;
	public static boolean 		APPEAR = false; 
	public static boolean 		INDENT = false;
	public static boolean 		IMAGES = true;

	protected void paintVerticalPartOfLeg(Graphics g, Rectangle clipBounds,
			Insets insets, TreePath path) {
		// dont paint it
	}

	protected void paintHorizontalPartOfLeg(Graphics g, Rectangle clipBounds,
			Insets insets, Rectangle bounds,
			TreePath path, int row,
			boolean isExpanded,
			boolean hasBeenExpanded, boolean
			isLeaf) {
		// dont paint it
	}

	protected void paintRow(Graphics g, Rectangle clipBounds,
			Insets insets, Rectangle bounds, TreePath path,
			int row, boolean isExpanded,
			boolean hasBeenExpanded, boolean isLeaf) {

		// Don't paint the renderer if editing this row.
		if(editingComponent != null && editingRow == row)
			return;

		int leadIndex;

		if(tree.hasFocus()) {
			leadIndex = getRowForPath(tree, tree.getLeadSelectionPath());
		} else {
			leadIndex = -1;
		}

		Component component = currentCellRenderer.getTreeCellRendererComponent
		(tree, path.getLastPathComponent(),
				tree.isRowSelected(row), isExpanded, isLeaf, row,
				(leadIndex == row));

		// set default font
		component.setFont(rowFont);

		// set size
//		int indent = this.getRowX(row, path.getPath().length); 
		int indent = this.getLeftChildIndent() + this.getRightChildIndent();
		
		component.setMinimumSize(new Dimension(tree.getParent().getWidth() - indent, bounds.height));
		component.setPreferredSize(new Dimension(tree.getParent().getWidth() - indent, bounds.height));

		// render for quality
		Graphics2D g2d = (Graphics2D) g;
		g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
				RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		g2d.setRenderingHint(RenderingHints.KEY_RENDERING,
				RenderingHints.VALUE_RENDER_QUALITY);

		int xOffset = 0;

		// if parent
		if (path.getPath().length == 2) {
			// set gradient paint
			GradientPaint paint = new GradientPaint(0, bounds.y, parentTopColor, 
					0, bounds.y + this.getRowHeight() - 1, parentBottomColor);

			// fill rectangle
			g2d.setPaint(paint);
			g.fillRect(0, bounds.y + 2, tree.getParent().getWidth(), bounds.height - 2);

			// draw border lines
			g.setColor(parentTopBorder1Color);
			g.drawLine(0, bounds.y + 0, tree.getParent().getWidth(), bounds.y + 0);
			g.setColor(parentTopBorder2Color);
			g.drawLine(0, bounds.y + 1, tree.getParent().getWidth(), bounds.y + 1);
			g.setColor(parentBottomBorder1Color);
			g.drawLine(0, bounds.y + bounds.height - 1, tree.getParent().getWidth(), bounds.y + bounds.height - 1);

			// set font color
			component.setForeground(parentFontColor);

			// set font bold
			component.setFont(rowFont.deriveFont(Font.BOLD));

			// set icon
			if (((DecoratedTreeNode)path.getLastPathComponent()).getChildCount() > 0) {
				if (isExpanded) {
					((DecoratedTreeCellRenderer)component).setIcon(collapsedImage);
				} else {
					((DecoratedTreeCellRenderer)component).setIcon(expandedImage);
				}
			} else {
				((DecoratedTreeCellRenderer)component).setIcon(noChildrenImage);
			}

			if (SHADOW) {
				g.setColor(Color.GRAY);
				g.setFont(rowFont.deriveFont(Font.BOLD));
				g.drawString(((DecoratedTreeCellRenderer)component).getText(), bounds.x + 15, bounds.y + 14);
			}

		// for child
		} else {
			// Calculate x offset in case a slide or appear needs to be done
			DecoratedTreeNode node = (DecoratedTreeNode)path.getLastPathComponent();
			DecoratedTreeNode parent = (DecoratedTreeNode) node.getParent();
			int childCount = parent.getChildCount();
			int indexInParent = parent.getIndex((DecoratedTreeNode)path.getLastPathComponent());
			indexInParent++; // start count from 1 and not 0		
			float completeness = parent.getExpansionCompleteness();
			double slidePercent = 1.0;
			if (SLIDE || APPEAR) {
				if (completeness < 1.0) {
					int totalSteps = SLIDE_STEPS + childCount - 1; 
					int rowStepEnd = SLIDE_STEPS + indexInParent - 1; 
					int currentStep = (int)(completeness * totalSteps);

					if (SLIDE) {
						slidePercent = Math.min(1.0, (currentStep * 1.0) / (rowStepEnd * 1.0));
					} else {
						slidePercent = Math.min(1.0, (currentStep ) / (rowStepEnd ));
					}
				}
				xOffset = (int)(tree.getParent().getWidth() * (1.0 - slidePercent));
			}

			// toggle background between two colors
			if (row % 2 != 0) {
				g.setColor(childColorOdd);
			} else {
				g.setColor(childColorEven);
			}
			if (!INDENT) {
				indent = 0;
			} else {
				indent -= 3; // otheriwse text sticks to the background box
			}
			if (SLIDE_TEXT_ONLY) {
				g.fillRect(0 + indent, bounds.y, tree.getParent().getWidth() - indent, bounds.height);
			} else {
				g.fillRect(0 + xOffset + indent, bounds.y, tree.getParent().getWidth() - indent, bounds.height);
			}

			// set font color
			component.setForeground(childFontColor);

			// set icon
			if (IMAGES) {
				((DecoratedTreeCellRenderer)component).setIcon(
						((DecoratedTreeCellRenderer)component).getImage());
			} else {
				((DecoratedTreeCellRenderer)component).setIcon(
						null);
			}

		}

		// set selection mask
		if (tree.isRowSelected(row)) {
			float completeness = ((DecoratedTreeNode)path.getLastPathComponent()).getSelectionCompleteness();
			g.setColor(new Color(selectectionMask.getRed(), 
					selectectionMask.getGreen(), 
					selectectionMask.getBlue(), 
					(int)(completeness * selectectionMask.getAlpha())));
			g.fillRect(0, bounds.y, tree.getParent().getWidth(), bounds.height);
		}

		rendererPane.paintComponent(g, component, tree, bounds.x + xOffset, bounds.y,
				bounds.width, bounds.height, true);	
	}

}
