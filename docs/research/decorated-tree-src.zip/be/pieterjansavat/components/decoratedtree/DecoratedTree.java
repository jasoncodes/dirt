/**
 *    Copyright 2006 Pieter-Jan Savat
 *    
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *    
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package be.pieterjansavat.components.decoratedtree;
import java.util.LinkedList;
import java.util.List;

import javax.swing.JTree;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeWillExpandListener;
import javax.swing.tree.ExpandVetoException;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

/**
 * The decorated tree uses specific nodes of type DecoratedNode. 
 * If you want to use it, make sure you use this type for your nodes
 * or that you extend it.
 * 
 * @author Pieter-Jan Savat
 */
public class DecoratedTree extends JTree implements TreeSelectionListener, TreeWillExpandListener {

	protected boolean animateSelection;
	
	public DecoratedTree() {
		super();
		initialize();
	}
	
	public DecoratedTree(TreeNode root) {
		super(root);
		initialize();
	}
	
	public void setSelectionAnimationEnabled(boolean bool) {
		animateSelection = bool;
	}
	
	private void initialize() {
		animateSelection = true;
		this.setRootVisible(false);
		this.setToggleClickCount(1);
		this.setCellRenderer( new DecoratedTreeCellRenderer() );		
		this.setRowHeight(20);
		this.setUI(new DecoratedTreeUI());

		this.addTreeSelectionListener(this);
		this.addTreeWillExpandListener(this);
	}
	
	public void valueChanged(TreeSelectionEvent e) {
		TreePath[] paths = e.getPaths();
		List<Object> selectedNodes = new LinkedList<Object>();
		for (TreePath path : paths) {
			if (this.isPathSelected(path)) {
				for (Object node : path.getPath()) {
					if (!selectedNodes.contains(node)) {
						selectedNodes.add(node);
					}
				}
			}
		}	
		
		if (animateSelection) {
			SelectionAnimator animator = new SelectionAnimator (selectedNodes.toArray());
	        animator.start();
		} else {
			for (Object o : selectedNodes) {
				((DecoratedTreeNode)o).setSelectionCompleteness(1.0f);
			}
		}
	}
	
    public static final int ANIMATION_DURATION = 500;
    public static final int ANIMATION_REFRESH = 50;
	
	class SelectionAnimator extends Thread {
        Object[] selections;
        long startTime;
        long stopTime;
        
        public SelectionAnimator (Object[] s) {
            selections = s;
        }
        
		public void run() {
			startTime = System.currentTimeMillis();
            stopTime = startTime + ANIMATION_DURATION;
            while (System.currentTimeMillis() < stopTime) {
                colorizeSelections();
                repaint();
                try { Thread.sleep (ANIMATION_REFRESH); } 
                catch (InterruptedException ie) {}
            }
            // one more, at 100% selected color
            colorizeSelections();
            repaint();
		}
		public void colorizeSelections() {
            // calculate % completion relative to start/stop times
            float elapsed = (float) (System.currentTimeMillis() - startTime);
            float completeness = Math.min ((elapsed/ANIMATION_DURATION), 1.0f);
			for (Object o : selections) {
				((DecoratedTreeNode)o).setSelectionCompleteness(completeness);
			}
		}
	}

	class ExpansionAnimator extends Thread {
		private DecoratedTreeNode node;
		private long startTime;
        private long stopTime;
        private int duration;
        
        public ExpansionAnimator (DecoratedTreeNode node) {
            this.node = node;
        }
        
		public void run() {
			startTime = System.currentTimeMillis();
			
			// calculate duration depending on the number of children
			// with an upper limit of 500 ms
			duration = 0;
			if (node.getChildCount() != 0) {
				duration = Math.min(500, 200 + (node.getChildCount() - 1) * 60);
			}
			int refresh = duration / 10;
			
            stopTime = startTime + duration;
            while (System.currentTimeMillis() < stopTime) {
                colorizeSelections();
                repaint();
                try { Thread.sleep (refresh); } 
                catch (InterruptedException ie) {}
            }
            // one more, at 100% selected color
            colorizeSelections();
            repaint();
		}
		public void colorizeSelections() {
            // calculate % completion relative to start/stop times
            float elapsed = (float) (System.currentTimeMillis() - startTime);
            float completeness = Math.min ((elapsed/duration), 1.0f);
            node.setExpansionCompleteness(completeness);
			
		}
	}
	
	public void treeWillCollapse(TreeExpansionEvent e) throws ExpandVetoException {
	}

	public void treeWillExpand(TreeExpansionEvent e) throws ExpandVetoException {
		DecoratedTreeNode node = (DecoratedTreeNode)e.getPath().getLastPathComponent();
		if (animateSelection) {
			ExpansionAnimator animator = new ExpansionAnimator (node);
	        animator.start();
		} else {
			node.setExpansionCompleteness(1.0f);
		}
	}
	
}