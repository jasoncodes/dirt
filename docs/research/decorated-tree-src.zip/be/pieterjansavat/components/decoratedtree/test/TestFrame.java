/**
 *    Copyright 2006 Pieter-Jan Savat
 *    
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *    
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package be.pieterjansavat.components.decoratedtree.test;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.UIManager;

import java.awt.Dimension;
import javax.swing.JPanel;

import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.BorderLayout;
import javax.swing.JCheckBox;
import java.awt.GridBagConstraints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JRadioButton;
import javax.swing.border.LineBorder;
import javax.swing.tree.DefaultMutableTreeNode;

import be.pieterjansavat.components.decoratedtree.DecoratedTree;
import be.pieterjansavat.components.decoratedtree.DecoratedTreeNode;
import be.pieterjansavat.components.decoratedtree.DecoratedTreeUI;
import be.pieterjansavat.components.decoratedtree.test.themes.BlackTreeTheme;
import be.pieterjansavat.components.decoratedtree.test.themes.TreeTheme;

import javax.swing.JComboBox;

public class TestFrame extends JFrame {

	private JPanel jPanel = null;
	private JPanel jPanel1 = null;
	private JPanel jPanel2 = null;
	private JCheckBox imgCheckBox = null;
	private JCheckBox animCheckBox = null;
	private JRadioButton slideRadioButton = null;
	private JRadioButton slideBgRadioButton = null;
	private JRadioButton appearRadioButton = null;
	private JCheckBox indentCheckBox = null;
	private DecoratedTree tree = null;
	private JComboBox themeComboBox = null;  //  @jve:decl-index=0:visual-constraint="582,311"

	/**
	 * This method initializes 
	 * 
	 */
	public TestFrame() {
		super();
		initialize();
		
		ButtonGroup group = new ButtonGroup();
	    group.add(slideRadioButton);
	    group.add(slideBgRadioButton);
	    group.add(appearRadioButton);
	    
	    imgCheckBox.setSelected(true);
	    animCheckBox.setSelected(true);
	    slideRadioButton.setSelected(true);
	}

	/**
	 * This method initializes this
	 * 
	 */
	private void initialize() {
        this.setSize(new Dimension(340, 532));
        this.setContentPane(getJPanel());
        this.setTitle("Decorated tree test");
			
	}

	/**
	 * This method initializes jPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel() {
		if (jPanel == null) {
			jPanel = new JPanel();
			jPanel.setLayout(new BorderLayout());
			jPanel.add(getJPanel1(), BorderLayout.SOUTH);
			jPanel.add(getJPanel2(), BorderLayout.CENTER);
		}
		return jPanel;
	}

	/**
	 * This method initializes jPanel1	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel1() {
		if (jPanel1 == null) {
			GridBagConstraints gridBagConstraints5 = new GridBagConstraints();
			gridBagConstraints5.gridx = 0;
			gridBagConstraints5.fill = GridBagConstraints.BOTH;
			gridBagConstraints5.gridy = 4;
			GridBagConstraints gridBagConstraints4 = new GridBagConstraints();
			gridBagConstraints4.fill = GridBagConstraints.BOTH;
			GridBagConstraints gridBagConstraints3 = new GridBagConstraints();
			gridBagConstraints3.gridx = 1;
			gridBagConstraints3.fill = GridBagConstraints.BOTH;
			gridBagConstraints3.gridy = 3;
			GridBagConstraints gridBagConstraints2 = new GridBagConstraints();
			gridBagConstraints2.gridx = 1;
			gridBagConstraints2.fill = GridBagConstraints.BOTH;
			gridBagConstraints2.gridy = 2;
			GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
			gridBagConstraints1.gridx = 1;
			gridBagConstraints1.fill = GridBagConstraints.BOTH;
			gridBagConstraints1.gridy = 1;
			GridBagConstraints gridBagConstraints = new GridBagConstraints();
			gridBagConstraints.gridx = 0;
			gridBagConstraints.gridy = 1;
			
			GridBagConstraints gridBagConstraints6 = new GridBagConstraints();
			gridBagConstraints6.gridx = 0;
			gridBagConstraints6.fill = GridBagConstraints.BOTH;
			gridBagConstraints6.gridy = 5;
			gridBagConstraints6.gridwidth = 2;
			
			jPanel1 = new JPanel();
			jPanel1.setLayout(new GridBagLayout());
			jPanel1.setBackground(new Color(254,255,223));
			jPanel1.setBorder(new LineBorder(Color.GRAY));
			jPanel1.add(getImgCheckBox(), gridBagConstraints4);
			jPanel1.add(getAnimCheckBox(), gridBagConstraints);
			jPanel1.add(getSlideRadioButton(), gridBagConstraints1);
			jPanel1.add(getSlideBgRadioButton(), gridBagConstraints2);
			jPanel1.add(getAppearRadioButton(), gridBagConstraints3);
			jPanel1.add(getIndentCheckBox(), gridBagConstraints5);
			jPanel1.add(getThemeComboBox(), gridBagConstraints6);
		}
		return jPanel1;
	}

	
	public static void createData(DefaultMutableTreeNode root) {
		
		int nr = 0;
		for (int i = 0; i < 10; i++) {
			DecoratedTreeNode sponsor = new DecoratedTreeNode();
			sponsor.setUserObject("Sponsor " + i);
			
			
			for (int j = 0; j < nr; j++) {
				DecoratedTreeNode study = new DecoratedTreeNode();
				study.setUserObject("Study " + j);	
				sponsor.add(study);
			}
			nr++;
			root.add(sponsor);
		}
	}
	
	/**
	 * This method initializes jPanel2	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel2() {
		if (jPanel2 == null) {
			jPanel2 = new JPanel();
			jPanel2.setLayout(new BorderLayout());
			
			DecoratedTreeNode root = new DecoratedTreeNode("root");
			createData(root);
			tree = new DecoratedTree(root);
			
			tree.setMinimumSize(new Dimension(300, 500));
			tree.setSize(300, 500);
			
			// set our tux renderer
			tree.setCellRenderer( new TuxTreeCellRenderer() );	
			tree.setSelectionAnimationEnabled(true);
			tree.setRowHeight(22);
			
			JScrollPane treeView = new JScrollPane(tree);
			treeView.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
			
			jPanel2.add(treeView, BorderLayout.CENTER);
		}
		return jPanel2;
	}

	/**
	 * This method initializes imgCheckBox	
	 * 	
	 * @return javax.swing.JCheckBox	
	 */
	private JCheckBox getImgCheckBox() {
		if (imgCheckBox == null) {
			imgCheckBox = new JCheckBox();
			imgCheckBox.setText("images");
			imgCheckBox.setOpaque(false);
			imgCheckBox.setFocusable(false);
			imgCheckBox.addActionListener(new ActionListener() {

				public void actionPerformed(ActionEvent e) {
					DecoratedTreeUI.IMAGES = imgCheckBox.isSelected();
					tree.repaint();
				}
				
			});
		}
		return imgCheckBox;
	}

	/**
	 * This method initializes animCheckBox	
	 * 	
	 * @return javax.swing.JCheckBox	
	 */
	private JCheckBox getAnimCheckBox() {
		if (animCheckBox == null) {
			animCheckBox = new JCheckBox();
			animCheckBox.setText("animations");
			animCheckBox.setOpaque(false);
			animCheckBox.setFocusable(false);
			animCheckBox.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					TestFrame.this.tree.setSelectionAnimationEnabled(animCheckBox.isSelected());
					
					slideRadioButton.setEnabled(animCheckBox.isSelected());
					slideBgRadioButton.setEnabled(animCheckBox.isSelected());
					appearRadioButton.setEnabled(animCheckBox.isSelected());
					
					tree.repaint();
				}
			});
		}
		return animCheckBox;
	}

	/**
	 * This method initializes slideRadioButton	
	 * 	
	 * @return javax.swing.JRadioButton	
	 */
	private JRadioButton getSlideRadioButton() {
		if (slideRadioButton == null) {
			slideRadioButton = new JRadioButton();
			slideRadioButton.setText("slide");
			slideRadioButton.setOpaque(false);
			slideRadioButton.setFocusable(false);
			slideRadioButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					if (!slideRadioButton.isSelected()) return;
					
					DecoratedTreeUI.SLIDE = slideRadioButton.isSelected();
					DecoratedTreeUI.SLIDE_TEXT_ONLY = slideRadioButton.isSelected();
					DecoratedTreeUI.APPEAR = !slideRadioButton.isSelected();
					
					tree.repaint();
				}
			});
		}
		return slideRadioButton;
	}

	/**
	 * This method initializes slideBgRadioButton	
	 * 	
	 * @return javax.swing.JRadioButton	
	 */
	private JRadioButton getSlideBgRadioButton() {
		if (slideBgRadioButton == null) {
			slideBgRadioButton = new JRadioButton();
			slideBgRadioButton.setText("slide (with background)");
			slideBgRadioButton.setOpaque(false);
			slideBgRadioButton.setFocusable(false);
			slideBgRadioButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					if (!slideBgRadioButton.isSelected()) return;
					
					DecoratedTreeUI.SLIDE = slideBgRadioButton.isSelected();
					DecoratedTreeUI.SLIDE_TEXT_ONLY = !slideBgRadioButton.isSelected();
					DecoratedTreeUI.APPEAR = !slideBgRadioButton.isSelected();
					
					tree.repaint();
				}
			});
		}
		return slideBgRadioButton;
	}

	/**
	 * This method initializes appearRadioButton	
	 * 	
	 * @return javax.swing.JRadioButton	
	 */
	private JRadioButton getAppearRadioButton() {
		if (appearRadioButton == null) {
			appearRadioButton = new JRadioButton();
			appearRadioButton.setText("appear");
			appearRadioButton.setOpaque(false);
			appearRadioButton.setFocusable(false);
			appearRadioButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					if (!appearRadioButton.isSelected()) return;
					
					DecoratedTreeUI.SLIDE = !appearRadioButton.isSelected();
					DecoratedTreeUI.SLIDE_TEXT_ONLY = !appearRadioButton.isSelected();
					DecoratedTreeUI.APPEAR = appearRadioButton.isSelected();
					
					tree.repaint();
				}});
		}
		return appearRadioButton;
	}

	/**
	 * This method initializes indentCheckBox	
	 * 	
	 * @return javax.swing.JCheckBox	
	 */
	private JCheckBox getIndentCheckBox() {
		if (indentCheckBox == null) {
			indentCheckBox = new JCheckBox();
			indentCheckBox.setText("indent");
			indentCheckBox.setOpaque(false);
			indentCheckBox.setFocusable(false);
			indentCheckBox.addActionListener(new ActionListener() {

				public void actionPerformed(ActionEvent e) {
					DecoratedTreeUI.INDENT = indentCheckBox.isSelected();
					tree.repaint();
				}
				
			});
		}
		return indentCheckBox;
	}

	/**
	 * This method initializes themeComboBox	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getThemeComboBox() {
		if (themeComboBox == null) {
			String[] petStrings = { "Black", "Blue", 
					"Green", 
					"Grey", 
					"Indigo", 
					"Kaki", 
					"Lila", 
					"Orange", 
					"Pink", 
					"Purple", 
					"Salmon", 
					"Turquoise", 
					"Yellow"};
			
			themeComboBox = new JComboBox(petStrings);
			themeComboBox.setFocusable(false);
			themeComboBox.setSelectedIndex(0);
			themeComboBox.addActionListener(new ActionListener() {

				public void actionPerformed(ActionEvent e) {
					TreeTheme theme = TreeTheme.instance(themeComboBox.getSelectedItem().toString());
					
					DecoratedTreeUI.parentTopBorder1Color = theme.getParentTopBorder1Color();
					DecoratedTreeUI.parentTopBorder2Color = theme.getParentTopBorder2Color();
					DecoratedTreeUI.parentTopColor = theme.getParentTopColor();
					DecoratedTreeUI.parentBottomColor = theme.getParentBottomColor();
					DecoratedTreeUI.parentBottomBorder1Color = theme.getParentBottomBorder1Color();

					DecoratedTreeUI.childColorOdd = theme.getChildColorOdd();
					DecoratedTreeUI.childColorEven = theme.getChildColorEven();

					DecoratedTreeUI.selectectionMask = theme.getSelectectionMask();

					DecoratedTreeUI.parentFontColor = theme.getParentFontColor();
					DecoratedTreeUI.childFontColor = theme.getChildFontColor();
					tree.repaint();
					
				}});
			
			TreeTheme theme = new BlackTreeTheme();
			
			DecoratedTreeUI.parentTopBorder1Color = theme.getParentTopBorder1Color();
			DecoratedTreeUI.parentTopBorder2Color = theme.getParentTopBorder2Color();
			DecoratedTreeUI.parentTopColor = theme.getParentTopColor();
			DecoratedTreeUI.parentBottomColor = theme.getParentBottomColor();
			DecoratedTreeUI.parentBottomBorder1Color = theme.getParentBottomBorder1Color();

			DecoratedTreeUI.childColorOdd = theme.getChildColorOdd();
			DecoratedTreeUI.childColorEven = theme.getChildColorEven();

			DecoratedTreeUI.selectectionMask = theme.getSelectectionMask();
			
			DecoratedTreeUI.parentFontColor = theme.getParentFontColor();
			DecoratedTreeUI.childFontColor = theme.getChildFontColor();
			
		}
		return themeComboBox;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.setProperty("swing.aatext","true");
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {}
		
		TestFrame f = new TestFrame();
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);

	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
