/**
 *    Copyright 2006 Pieter-Jan Savat
 *    
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *    
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package be.pieterjansavat.components.decoratedtree.test.themes;

import java.awt.Color;

public abstract class TreeTheme {

	public static TreeTheme instance(String factory) {
		try {
			return (TreeTheme) TreeTheme.class.getClassLoader()
			.loadClass("be.pieterjansavat.components.decoratedtree.test.themes." + 
					factory + "TreeTheme").getConstructor().newInstance();
		} catch (Throwable ex) {
			throw new RuntimeException("Couldn't create factory: " + factory);
		}
	}

	public abstract Color getChildFontColor();
	public abstract Color getParentFontColor();
	public abstract Color getParentTopBorder1Color();
	public abstract Color getParentTopBorder2Color();
	public abstract Color getParentTopColor();
	public abstract Color getParentBottomColor ();
	public abstract Color getParentBottomBorder1Color ();

	public abstract Color getChildColorOdd ();
	public abstract Color getChildColorEven ();

	public abstract Color getSelectectionMask ();
}
