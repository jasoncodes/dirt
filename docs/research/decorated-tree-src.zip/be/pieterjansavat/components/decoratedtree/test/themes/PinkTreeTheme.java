/**
 *    Copyright 2006 Pieter-Jan Savat
 *    
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *    
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package be.pieterjansavat.components.decoratedtree.test.themes;

import java.awt.Color;


public class PinkTreeTheme extends TreeTheme {

	private static Color 	parentTopBorder1Color 	= new Color(211,139,202);
	private static Color 	parentTopBorder2Color 	= new Color(219,135,212);
	private static Color 	parentTopColor 			= new Color(235,169,233);
	private static Color 	parentBottomColor 		= new Color(197,99,186);
	private static Color 	parentBottomBorder1Color = new Color(225,167,217);
	
	private static Color 	childColorOdd 		= new Color(250,238,248);
	private static Color 	childColorEven 		= new Color(254,252,254);
	
	private static Color 	selectectionMask 	= new Color(149,35,129, 90);
	
	private static Color parentFontColor = Color.WHITE;
	private static Color childFontColor = Color.BLACK;
	
	public Color getChildFontColor() {
		return childFontColor;
	}

	public Color getParentFontColor() {
		return parentFontColor;
	}
	
	public Color getChildColorEven() {
		return childColorEven;
	}

	public Color getChildColorOdd() {
		return childColorOdd;
	}

	public Color getParentBottomBorder1Color() {
		return parentBottomBorder1Color;
	}

	public Color getParentBottomColor() {
		return parentBottomColor;
	}

	public Color getParentTopBorder1Color() {
		return parentTopBorder1Color;
	}

	public Color getParentTopBorder2Color() {
		return parentTopBorder2Color;
	}

	public Color getParentTopColor() {
		return parentTopColor;
	}

	public Color getSelectectionMask() {
		return selectectionMask;
	}
	
	
}
