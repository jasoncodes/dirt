/**
 *    Copyright 2006 Pieter-Jan Savat
 *    
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *    
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package be.pieterjansavat.components.decoratedtree.test;

import javax.swing.ImageIcon;

public class TuxFactory {

	private static ImageIcon[] tuxes;
	
	static {
		tuxes = new ImageIcon[7];
		
		tuxes[0] = new ImageIcon(TuxFactory.class.getResource("becassine11.png"));
		tuxes[1] = new ImageIcon(TuxFactory.class.getResource("Dupond11.png"));
		tuxes[2] = new ImageIcon(TuxFactory.class.getResource("MonTux11.png"));
		tuxes[3] = new ImageIcon(TuxFactory.class.getResource("SmockingTux11.png"));
		tuxes[4] = new ImageIcon(TuxFactory.class.getResource("tintin11.png"));
		tuxes[5] = new ImageIcon(TuxFactory.class.getResource("TuxChirurgien11.png"));
		tuxes[6] = new ImageIcon(TuxFactory.class.getResource("tuxCuisinier11.png"));
	}
	
	public static ImageIcon getTux(int index) {
		return tuxes[index % tuxes.length];
	}
	
}
